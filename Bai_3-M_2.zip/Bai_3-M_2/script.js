// script.js

// Dữ liệu câu hỏi sẽ được tải từ file JSON
let data = []; // Khởi tạo mảng rỗng, dữ liệu sẽ được điền vào sau khi tải

// Lấy các phần tử HTML cần thiết
const questionText = document.getElementById('question-text');
const choicesContainer = document.getElementById('choices-container');
const submitButton = document.getElementById('submit-button');
const nextButton = document.getElementById('next-button');
const explanationArea = document.getElementById('explanation-area');
const explanationText = document.getElementById('explanation-text');
const continueButton = document.getElementById('continue-button');
const questionArea = document.getElementById('question-area');
const resultArea = document.getElementById('result-area');
const scoreText = document.getElementById('score-text');
const restartButton = document.getElementById('restart-button');
const progressBar = document.getElementById('progressBar');
const progressText = document.getElementById('progressText');
const resultTitle = document.getElementById('result-title');
const feedbackText = document.getElementById('feedback-text');
const reviewButton = document.getElementById('review-button');

// Các phần tử mới cho Timer
const timerDisplay = document.getElementById('timerDisplay'); // Hiển thị đồng hồ
const timerToggle = document.getElementById('timerToggle');   // Nút bật/tắt timer

// Biến trạng thái trò chơi
let currentQuestionIndex = 0;
let score = 0;
let selectedChoice = -1;
let questionsAttempted = [];

// Biến trạng thái Timer
let timerInterval;          // ID của setInterval cho timer
const TIME_PER_QUESTION = 30; // Thời gian tối đa cho mỗi câu hỏi (giây)
const WARNING_TIME = 5;     // Thời gian còn lại để phát cảnh báo (giây)
// THÊM BIẾN MỚI: Thời gian để phát âm thanh timeout nhưng chưa kết thúc câu hỏi
const TIMEOUT_AUDIO_TRIGGER_TIME = 15; // Âm thanh timeout sẽ phát khi còn 15 giây
let timeLeft = TIME_PER_QUESTION; // Thời gian còn lại hiện tại
let isTimerEnabled = false; // Trạng thái bật/tắt của timer, mặc định là bật

// Tải âm thanh
const audioCorrect = new Audio('sounds/correct.mp3');
const audioWrong = new Audio('sounds/wrong.mp3');
const audioClick = new Audio('sounds/click.mp3');
const audioFinish = new Audio('sounds/finish.mp3');
const audioStart = new Audio('sounds/start.mp3');
const audioRestart = new Audio('sounds/restart.mp3');
const audioWarning = new Audio('sounds/warning.mp3'); // Âm thanh cảnh báo thời gian hết
const audioTimeout = new Audio('sounds/timeout.mp3'); // Âm thanh hết giờ

// Hàm xáo trộn mảng (Fisher-Yates shuffle algorithm)
function shuffleArray(array) {
    // Tạo một bản sao của mảng để không làm thay đổi mảng gốc.
    const shuffled = [...array];
    // Lặp ngược từ cuối mảng về đầu.
    for (let i = shuffled.length - 1; i > 0; i--) {
        // Chọn một chỉ số ngẫu nhiên từ 0 đến i.
        const j = Math.floor(Math.random() * (i + 1));
        // Hoán đổi phần tử tại vị trí i với phần tử tại vị trí j.
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    // Trả về mảng đã xáo trộn.
    return shuffled;
}

// Hàm cập nhật thanh tiến độ
function updateProgressBar() {
    // Tính toán tỷ lệ phần trăm tiến độ dựa trên số câu hỏi đã hoàn thành
    // (currentQuestionIndex) so với tổng số câu hỏi (data.length).
    const progress = (currentQuestionIndex / data.length) * 100;
    // Đặt chiều rộng của thanh tiến độ bằng giá trị phần trăm đã tính toán.
    progressBar.style.width = `${progress}%`;
    // Cập nhật văn bản hiển thị tiến độ (ví dụ: "3/10").
    progressText.textContent = `${currentQuestionIndex}/${data.length}`;
}

// Hàm định dạng thời gian (ví dụ: 00:30)
function formatTime(seconds) {
    // Tính số phút từ tổng số giây.
    const minutes = Math.floor(seconds / 60);
    // Tính số giây còn lại sau khi đã tính phút.
    const remainingSeconds = seconds % 60;
    // Sử dụng padStart để thêm số 0 vào đầu nếu số nhỏ hơn 10 (ví dụ: 05)
    return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
}

// Hàm bắt đầu bộ đếm ngược
function startTimer() {
    // Chỉ bắt đầu nếu timer được bật.
    if (!isTimerEnabled) {
        timerDisplay.textContent = formatTime(TIME_PER_QUESTION); // Vẫn hiển thị thời gian ban đầu
        timerDisplay.classList.remove('warning'); // Đảm bảo không có warning
        return; // Không chạy timer nếu bị tắt
    }

    // Đặt lại thời gian và hiển thị
    timeLeft = TIME_PER_QUESTION;
    timerDisplay.textContent = formatTime(timeLeft);
    timerDisplay.classList.remove('warning'); // Đảm bảo không có lớp warning cũ

    // Dừng timer hiện tại nếu có
    stopTimer();

    // Bắt đầu interval mới, cập nhật mỗi 1 giây
    timerInterval = setInterval(() => {
        timeLeft--; // Giảm thời gian còn lại
        timerDisplay.textContent = formatTime(timeLeft); // Cập nhật hiển thị

        // Logic phát âm thanh cảnh báo (nhấp nháy) khi thời gian sắp hết
        if (timeLeft === WARNING_TIME) {
            audioWarning.play();
            timerDisplay.classList.add('warning'); // Thêm class cảnh báo để nhấp nháy
        }

        // Logic phát âm thanh timeout (chỉ phát, không dừng câu hỏi)
        if (timeLeft === TIMEOUT_AUDIO_TRIGGER_TIME) {
            audioTimeout.play(); // Phát âm thanh timeout
        }

        // Khi hết giờ (đạt 0 giây)
        if (timeLeft <= 0) {
            stopTimer(); // Dừng timer
            timerDisplay.classList.remove('warning'); // Xóa warning
            checkAnswer(true); // Tự động kiểm tra đáp án (coi như hết giờ)
        }
    }, 1000); // Cập nhật mỗi 1000ms (1 giây)
}

// Hàm dừng bộ đếm ngược
function stopTimer() {
    clearInterval(timerInterval); // Xóa interval để dừng timer
    timerDisplay.classList.remove('warning'); // Đảm bảo xóa class warning
}

// Hàm hiển thị câu hỏi
function displayQuestion() {
    // Ẩn/hiện các khu vực chính
    questionArea.classList.remove('hidden');
    explanationArea.classList.add('hidden');
    resultArea.classList.add('hidden');

    // Cập nhật thanh tiến độ
    updateProgressBar();

    const currentQuestion = data[currentQuestionIndex];
    questionText.textContent = currentQuestion.questionText; // SỬA: 'question' -> 'questionText'

    choicesContainer.innerHTML = ''; // Xóa các lựa chọn cũ
    selectedChoice = -1; // Reset lựa chọn

    // Ẩn nút "Câu Kế Tiếp" và "Tiếp Tục"
    nextButton.classList.add('hidden');
    continueButton.classList.add('hidden');
    // Hiển thị nút "Kiểm Tra"
    submitButton.classList.remove('hidden');

    // Xáo trộn các lựa chọn và tạo nút
    const originalChoices = [...currentQuestion.options]; // SỬA: 'choices' -> 'options'
    const shuffledChoices = shuffleArray(originalChoices);

    shuffledChoices.forEach((choiceText) => {
        const button = document.createElement('button');
        button.textContent = choiceText;
        button.classList.add('choice-button');
        button.dataset.originalIndex = originalChoices.indexOf(choiceText);

        button.addEventListener('click', () => {
            audioClick.play();
            document.querySelectorAll('.choice-button').forEach(btn => {
                btn.classList.remove('selected', 'correct', 'wrong'); // Xóa tất cả trạng thái
                btn.disabled = false;
            });
            button.classList.add('selected');
            selectedChoice = parseInt(button.dataset.originalIndex);
        });
        choicesContainer.appendChild(button);
    });

    // Bắt đầu timer cho câu hỏi mới
    startTimer();
}

// Hàm kiểm tra câu trả lời
// isTimeout = true nếu hàm được gọi do hết giờ, false nếu do người dùng bấm nút
function checkAnswer(isTimeout = false) {
    // Dừng timer ngay lập tức khi người dùng chọn đáp án hoặc hết giờ
    stopTimer();

    // Nếu hết giờ mà người dùng chưa chọn đáp án nào
    if (isTimeout && selectedChoice === -1) {
        selectedChoice = -1; // Đảm bảo là chưa có lựa chọn
    } else if (selectedChoice === -1 && !isTimeout) {
        // Nếu người dùng bấm "Kiểm Tra" nhưng chưa chọn gì
        alert("Vui lòng chọn một đáp án trước khi kiểm tra!");
        startTimer(); // Bắt đầu lại timer nếu người dùng chưa chọn
        return;
    }

    const currentQuestion = data[currentQuestionIndex];
    const correctOriginalIndex = currentQuestion.correctAnswerIndex; // SỬA: 'answer' -> 'correctAnswerIndex'

    // isCorrect là true nếu selectedChoice trùng với correctOriginalIndex VÀ người dùng đã chọn (selectedChoice !== -1)
    let isCorrect = (selectedChoice !== -1 && selectedChoice === correctOriginalIndex);

    // Lưu trữ câu hỏi và kết quả để xem lại
    questionsAttempted.push({
        question: currentQuestion.questionText, // SỬA: 'question' -> 'questionText'
        choices: currentQuestion.options, // SỬA: 'choices' -> 'options'
        correctAnswerIndex: correctOriginalIndex,
        userAnswerIndex: selectedChoice, // Sẽ là -1 nếu hết giờ và chưa chọn
        isCorrect: isCorrect,
        explanation: currentQuestion.explanation,
        timedOut: isTimeout // Thêm trạng thái hết giờ
    });

    const choiceButtons = document.querySelectorAll('.choice-button');

    choiceButtons.forEach(button => {
        const buttonOriginalIndex = parseInt(button.dataset.originalIndex);
        button.disabled = true; // Vô hiệu hóa nút

        if (buttonOriginalIndex === correctOriginalIndex) {
            button.classList.add('correct'); // Đánh dấu đúng
        }
        // Nếu người dùng chọn và chọn sai, hoặc hết giờ mà đây là đáp án người dùng đã "tự động chọn" (nếu có logic tự chọn)
        // Hiện tại, nếu hết giờ và chưa chọn, không có nút nào có selectedChoice, nên chỉ cần kiểm tra !isCorrect
        if (buttonOriginalIndex === selectedChoice && !isCorrect) {
            button.classList.add('wrong'); // Đánh dấu sai
        }
        // Đặc biệt xử lý trường hợp hết giờ mà người dùng chưa chọn gì
        if (isTimeout && selectedChoice === -1) {
             // Không làm gì với các nút, coi như không có lựa chọn nào được highlight sai
             // Hoặc có thể tự động highlight tất cả các nút (trừ nút đúng) là sai, tùy thiết kế.
             // Hiện tại chỉ đánh dấu nút đúng.
        }

        button.classList.remove('selected'); // Loại bỏ trạng thái selected
    });

    if (isCorrect) {
        score++;
        audioCorrect.play();
    } else {
        audioWrong.play();
    }

    submitButton.classList.add('hidden');
    explanationArea.classList.remove('hidden');
    explanationText.textContent = currentQuestion.explanation;

    if (currentQuestionIndex < data.length - 1) {
        continueButton.classList.remove('hidden');
    } else {
        nextButton.classList.remove('hidden');
        nextButton.textContent = "Hoàn Thành Trò Chơi";
    }
}

// Hàm chuyển sang câu hỏi kế tiếp hoặc kết thúc trò chơi
function nextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < data.length) {
        displayQuestion();
    } else {
        showResult();
    }
}

// Hàm hiển thị kết quả cuối cùng
function showResult() {
    audioFinish.play();
    questionArea.classList.add('hidden');
    explanationArea.classList.add('hidden');
    resultArea.classList.remove('hidden');

    stopTimer(); // Đảm bảo dừng timer khi kết thúc trò chơi

    updateProgressBar(); // Cập nhật thanh tiến độ lần cuối

    scoreText.textContent = `Bạn đã trả lời đúng ${score} / ${data.length} câu hỏi.`;

    const percentage = (score / data.length) * 100;
    if (percentage === 100) {
        resultTitle.textContent = "Tuyệt vời!";
        feedbackText.textContent = "Bạn là một chuyên gia thực sự! Không có câu hỏi nào làm khó được bạn.";
        resultTitle.style.color = '#27ae60';
    } else if (percentage >= 70) {
        resultTitle.textContent = "Rất tốt!";
        feedbackText.textContent = "Bạn đã có kiến thức rất vững chắc. Cố gắng thêm một chút nữa nhé!";
        resultTitle.style.color = '#f39c12';
    } else {
        resultTitle.textContent = "Hãy cố gắng hơn!";
        feedbackText.textContent = "Bạn đã có một khởi đầu tốt. Hãy xem lại các câu hỏi và thử lại nhé.";
        resultTitle.style.color = '#c0392b';
    }

    if (score < data.length) {
        reviewButton.classList.remove('hidden');
    } else {
        reviewButton.classList.add('hidden');
    }
}

// Hàm xem lại các câu trả lời sai (Chức năng mở rộng, cần triển khai chi tiết hơn)
function reviewWrongAnswers() {
    alert("Chức năng xem lại câu sai sẽ được phát triển trong tương lai!");
    // Đây là nơi bạn sẽ triển khai logic để hiển thị các câu hỏi mà người dùng đã trả lời sai.
    // Lọc questionsAttempted.filter(q => !q.isCorrect) để lấy danh sách các câu sai.
    // Sau đó hiển thị chúng trong một modal hoặc một giao diện riêng.
}


// Hàm khởi động lại trò chơi
function restartGame() {
    audioRestart.play();
    currentQuestionIndex = 0;
    score = 0;
    selectedChoice = -1;
    questionsAttempted = [];
    displayQuestion(); // Bắt đầu lại
}

// Gắn các sự kiện cho nút
submitButton.addEventListener('click', () => checkAnswer(false)); // Khi bấm, không phải do timeout
nextButton.addEventListener('click', nextQuestion);
continueButton.addEventListener('click', nextQuestion);
restartButton.addEventListener('click', restartGame);
reviewButton.addEventListener('click', reviewWrongAnswers);

// Gắn sự kiện cho nút bật/tắt timer
timerToggle.addEventListener('change', () => {
    isTimerEnabled = timerToggle.checked; // Cập nhật trạng thái timer
    // Nếu timer bị tắt, đảm bảo nó dừng lại và reset hiển thị
    if (!isTimerEnabled) {
        stopTimer();
        timerDisplay.textContent = formatTime(TIME_PER_QUESTION); // Reset hiển thị thời gian
        timerDisplay.classList.remove('warning');
    } else {
        // Nếu bật lại khi đang ở câu hỏi, khởi động lại timer
        if (questionArea.classList.contains('hidden') === false && explanationArea.classList.contains('hidden') === true) {
             startTimer(); // Chỉ start lại nếu đang ở màn hình câu hỏi
        }
    }
});


// Khởi tạo trò chơi khi trang web tải xong
// Hàm tải dữ liệu câu hỏi từ file JSON
async function loadQuizData() {
    try {
        const response = await fetch('output_quiz_data.json');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        data = await response.json();
        // Xáo trộn dữ liệu sau khi tải
        data = shuffleArray(data); // Đảm bảo các câu hỏi được xáo trộn mỗi lần tải
        displayQuestion();
        audioStart.play();
        // Đảm bảo trạng thái timerToggle được thiết lập đúng khi tải trang
        timerToggle.checked = isTimerEnabled;
    } catch (error) {
        console.error("Could not load quiz data:", error);
        questionText.textContent = "Không thể tải dữ liệu câu hỏi. Vui lòng kiểm tra file output_quiz_data.json.";
        choicesContainer.innerHTML = '';
        submitButton.classList.add('hidden');
        nextButton.classList.add('hidden');
        continueButton.classList.add('hidden');
        restartButton.classList.add('hidden');
        reviewButton.classList.add('hidden');
        timerToggle.classList.add('hidden'); // Ẩn nút bật/tắt timer nếu không có dữ liệu
        timerDisplay.classList.add('hidden'); // Ẩn hiển thị timer
    }
}

// Khởi tạo trò chơi khi trang web tải xong
window.addEventListener('load', loadQuizData); // Gọi hàm tải dữ liệu khi trang web được tải.